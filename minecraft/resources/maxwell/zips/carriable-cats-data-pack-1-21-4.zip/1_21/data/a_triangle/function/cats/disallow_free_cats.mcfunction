scoreboard players set ▲ a_triangle.enable_cat_triggers 0
scoreboard players reset @a[tag=!global.ignore] a_triangle.maxwell
scoreboard players reset @a[tag=!global.ignore] a_triangle.mars
scoreboard players reset @a[tag=!global.ignore] a_triangle.valenok
scoreboard players reset @a[tag=!global.ignore] a_triangle.vasilisa