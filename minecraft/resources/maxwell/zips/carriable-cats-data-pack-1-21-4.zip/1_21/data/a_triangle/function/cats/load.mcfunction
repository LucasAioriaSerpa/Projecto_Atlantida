scoreboard objectives add a_triangle.cats_right_click minecraft.used:warped_fungus_on_a_stick
scoreboard objectives add a_triangle.maxwell trigger
scoreboard objectives add a_triangle.mars trigger
scoreboard objectives add a_triangle.valenok trigger
scoreboard objectives add a_triangle.vasilisa trigger
scoreboard objectives add a_triangle.enable_cat_triggers dummy
scoreboard players set ▲ a_triangle.enable_cat_triggers 1