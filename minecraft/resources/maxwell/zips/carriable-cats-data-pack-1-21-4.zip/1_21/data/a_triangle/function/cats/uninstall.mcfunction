scoreboard objectives remove a_triangle.cats_right_click
scoreboard objectives remove a_triangle.enable_cat_triggers
scoreboard objectives remove a_triangle.mars
scoreboard objectives remove a_triangle.maxwell
scoreboard objectives remove a_triangle.valenok
scoreboard objectives remove a_triangle.vasilisa
datapack disable "file/carryable-cats-data-pack.zip"