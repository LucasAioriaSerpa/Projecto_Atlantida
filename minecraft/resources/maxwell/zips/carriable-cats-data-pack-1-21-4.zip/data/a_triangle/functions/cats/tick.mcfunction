execute as @a[tag=!global.ignore,scores={a_triangle.maxwell=1..}] run function a_triangle:cats/give_maxwell
execute as @a[tag=!global.ignore,scores={a_triangle.mars=1..}] run function a_triangle:cats/give_mars
execute as @a[tag=!global.ignore,scores={a_triangle.valenok=1..}] run function a_triangle:cats/give_valenok
execute as @a[tag=!global.ignore,scores={a_triangle.vasilisa=1..}] run function a_triangle:cats/give_vasilisa
scoreboard players reset @a[tag=!global.ignore,scores={a_triangle.maxwell=1..}] a_triangle.maxwell
scoreboard players reset @a[tag=!global.ignore,scores={a_triangle.mars=1..}] a_triangle.mars
scoreboard players reset @a[tag=!global.ignore,scores={a_triangle.valenok=1..}] a_triangle.valenok
scoreboard players reset @a[tag=!global.ignore,scores={a_triangle.vasilisa=1..}] a_triangle.vasilisa
execute if score ▲ a_triangle.enable_cat_triggers matches 1 run scoreboard players enable @a[tag=!global.ignore] a_triangle.maxwell
execute if score ▲ a_triangle.enable_cat_triggers matches 1 run scoreboard players enable @a[tag=!global.ignore] a_triangle.mars
execute if score ▲ a_triangle.enable_cat_triggers matches 1 run scoreboard players enable @a[tag=!global.ignore] a_triangle.valenok
execute if score ▲ a_triangle.enable_cat_triggers matches 1 run scoreboard players enable @a[tag=!global.ignore] a_triangle.vasilisa
execute as @a[tag=!global.ignore] if score @s a_triangle.cats_right_click matches 1.. run function a_triangle:cats/right_click
execute as @e[type=item,nbt={Item:{tag:{a_triangle.cat:1b}}}] run data merge entity @s {Age:-32768,Health:32767}
kill @e[type=item,nbt={PickupDelay:32767s,Item:{tag:{a_triangle.cat:1b}}}]